package Decorator;

public interface Car {
    public void assemble();
    public long carPrice();
}
